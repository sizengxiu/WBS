create trigger trg__menu_update_copy
  before UPDATE
  on blog_menu_copy
  for each row
  set new.update_time=CURRENT_TIMESTAMP;

