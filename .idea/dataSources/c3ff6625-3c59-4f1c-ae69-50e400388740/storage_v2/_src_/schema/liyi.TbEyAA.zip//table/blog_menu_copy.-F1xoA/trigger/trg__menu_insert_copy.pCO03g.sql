create trigger trg__menu_insert_copy
  before INSERT
  on blog_menu_copy
  for each row
  set new.create_time=CURRENT_TIMESTAMP,new.update_time=CURRENT_TIMESTAMP;

