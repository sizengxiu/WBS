create trigger trg__menu_update
  before UPDATE
  on blog_menu
  for each row
  set new.update_time=CURRENT_TIMESTAMP;

